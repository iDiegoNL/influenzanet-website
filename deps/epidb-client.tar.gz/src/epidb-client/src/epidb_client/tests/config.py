api_key = '0000000000000000000000000000000000000000'
api_key_invalid = '000000000000000000000000000000000000000X'
server = 'http://localhost:8080/'
user_id = '00000000-0000-0000-0000-000000000000';
session_id = '0000000000000000000000000000000000000002'

survey_id = 'dev-response-example-0.0'
profile_survey_id = 'dev-profile-example-0.0'

# vim: set ts=4 sts=4 expandtab:
